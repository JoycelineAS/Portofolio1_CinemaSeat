﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace week7
{
    internal class MovieTime
    {
        public Movie movie { get; set; }
        public string time { get; set; }
        public List<List<Seat>> seats { get; set; }



        public MovieTime(Movie movie, string time)
        {
            this.movie = movie;
            this.time = time;

            int unicodeA = 65;
            Random rnd = new Random();
            int unavailable = rnd.Next(70);
            this.seats = new List<List<Seat>>();
            for (int i = 0; i < 10; i++)
            {
                this.seats.Add(new List<Seat>());
                for (int j = 0; j < 10; j++)
                {
                    bool available;
                    if (unavailable <=0) available = true;
                    else available = rnd.Next(1, 5000) % 2 == 0;

                    if (!available) unavailable--;
                    char character = (char)(unicodeA + j);
                    string col = character.ToString();
                    this.seats[i].Add(new Seat(available, col, i+""));
                }
            }
        }
    }
}
